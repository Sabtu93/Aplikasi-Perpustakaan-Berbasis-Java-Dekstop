/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Peminjaman;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
/**
 *
 * @author lenovo
 */
public class Koneksi {
    static Connection Peminjaman;
    public static Connection getConnection() {
        try{
            Peminjaman = DriverManager.getConnection("jdbc:mysql://localhost/perpustakaan","root", "");
    }catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Koneksi Gagal");
    }
        return Peminjaman;
    }
}
